require('dotenv').config();
const express = require('express');
// import fs from 'fs';
// import pdf from 'pdf-parse';
var cors = require('cors')
// import { Request, Response } from 'express';
const jwtDecode = require('jwt-decode');
//import { TokenSet } from 'openid-client';
const { XeroAccessToken, XeroIdToken, 
	XeroClient, Contact, LineItem, Invoice, 
	Invoices, Phone, Contacts } = require('xero-node');

const session = require('express-session');

const client_id = process.env.CLIENT_ID;
const client_secret = process.env.CLIENT_SECRET;
const redirectUrl = process.env.REDIRECT_URI;
const scopes = 'openid profile email accounting.settings accounting.reports.read accounting.journals.read accounting.contacts accounting.attachments accounting.transactions offline_access';

const xero = new XeroClient({
	clientId: client_id,
	clientSecret: client_secret,
	redirectUris: [redirectUrl],
	scopes: scopes.split(' '),
});

if (!client_id || !client_secret || !redirectUrl) {
	throw Error('Environment Variables not all set - please check your .env file in the project root or create one!')
}

const app = express();
app.use(express.static('public'));
app.use(express.json());


app.use(express.static(__dirname + '/build'));
app.use(cors());
app.use(session({
	secret: 'something crazy',
	resave: false,
	saveUninitialized: true,
	cookie: { secure: false },
}));

app.set('views','./src/views')
app.set('view engine', 'ejs')



const authenticationData = (req, res) => {
	return {
		decodedIdToken: req.session.decodedIdToken,
		decodedAccessToken: req.session.decodedAccessToken,
		tokenSet: req.session.tokenSet,
		allTenants: req.session.allTenants,
		activeTenant: req.session.activeTenant,
	};
};

app.get('/', (req, res) => {
	res.send(`<a href='/connect'>Connect to Xero</a>`);
});

app.get('/connect', async (req, res) => {
	try {
		const consentUrl = await xero.buildConsentUrl();
		res.redirect(consentUrl);
	} catch (err) {
		res.send('Sorry, something went wrong');
	}
});

app.get('/callback', async (req, res) => {
	try {
		const tokenSet = await xero.apiCallback(req.url);
		await xero.updateTenants();

		const decodedIdToken = jwtDecode(tokenSet.id_token);
		const decodedAccessToken = jwtDecode(tokenSet.access_token);

		req.session.decodedIdToken = decodedIdToken;
		req.session.decodedAccessToken = decodedAccessToken;
		req.session.tokenSet = tokenSet;
		req.session.allTenants = xero.tenants;
		// XeroClient is sorting tenants behind the scenes so that most recent / active connection is at index 0
		req.session.activeTenant = xero.tenants[0];

		const authData = authenticationData(req, res);

		res.redirect('/organisation');
	} catch (err) {
		res.send('Sorry, something went wrong');
	}
});

app.get('/organisation', async (req, res) => {
	try {
		const tokenSet = await xero.readTokenSet();
		const response = await xero.accountingApi.getOrganisations(req.session.activeTenant.tenantId);
		//res.send(`Hello, ${response.body.organisations[0].name}`);
		res.render('contact')
	} catch (err) {
		res.send('Sorry, something went wrong');
	}
});

app.get('/invoice', async (req, res) => {
	try {
		const contacts = await xero.accountingApi.getContacts(req.session.activeTenant.tenantId);


		// const where = 'Status=="ACTIVE" AND Type=="SALES"';
		// const accounts = await xero.accountingApi.getAccounts(req.session.activeTenant.tenantId, null, where);
		// console.log('accounts: ', accounts.body.accounts);

		const contact = {
			contactID: contacts.body.contacts[0].contactID
		};

		// ************ 

		const lineItem = { 
			description: "HTML",
			quantity: 1.0,
			unitAmount: 200.0,
			accountCode: "000",
			// tracking: lineItemTrackings
		  };   
		  const lineItems = [];
		  lineItems.push(lineItem)


		// ************



		// const lineItem: LineItem = {
		// 	accountID: accounts.body.accounts[0].accountID,
		// 	description: 'consulting',
		// 	quantity: 1.0,
		// 	unitAmount: 10.0
		// };


		const invoice = {
			lineItems: [lineItem],
			contact: contact,
			dueDate: '2021-09-25',
			date: '2021-09-24',
			type: Invoice.TypeEnum.ACCREC
		};
		const invoices = {
			invoices: [invoice]
		};
		const response = await xero.accountingApi.createInvoices(req.session.activeTenant.tenantId, invoices);
		console.log('invoices: ', response.body.invoices);
		res.json(response.body);
	} catch (err) {
		res.json(err);
	}
});

app.get('/userInvoice', async (req, res) => {
	// await xero.setTokenSet(tokenSet);

	// const xeroTenantId = req.session.activeTenant.tenantId;
	const invoiceID = 'dee4168e-54bc-448c-9119-73b998e835b2';
	const fileName = 'xero-dev.jpg';
	const contentType = 'image/jpg'; 
	const unitdp = 4;

	try {
		// const response = await xero.accountingApi.getInvoice(req.session.activeTenant.tenantId, invoiceID,  unitdp);
		const response = await xero.accountingApi.getInvoiceAsPdf(req.session.activeTenant.tenantId, invoiceID);
		// const response = await xero.accountingApi.getInvoiceAttachmentByFileName(req.session.activeTenant.tenantId, invoiceID, fileName, contentType);

		console.log(response.body || response.response.statusCode)

		res.json(response.body); 
	} catch (err) {
		const error = JSON.stringify(err.response.body, null, 2)
		console.log(`Status Code: ${err.response.statusCode} => ${error}`);
	}
});

app.get('/contact', async (req, res) => {
	try {
		const contact = {
			name: "abcdtest",
			firstName: "lasttest",
			lastName: "lasttest22",
			emailAddress: "lasttest@gmail.com",
			phones: [
				{
					phoneNumber:'555-555-5555',
					phoneType: Phone.PhoneTypeEnum.MOBILE
				}
			]
		};
		const contacts = {  
			contacts: [contact]
		};
		const response = await xero.accountingApi.createContacts(req.session.activeTenant.tenantId, contacts);
		console.log('contacts: ', response.body);
		res.json(response.body);
	} catch (err) {
		res.json(err);
	}
});


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
	console.log(`App listening on port ${PORT}`);
});